# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

from .resnet import resnet50